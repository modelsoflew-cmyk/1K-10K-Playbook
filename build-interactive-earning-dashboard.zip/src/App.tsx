import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Home,
  Target,
  Lightbulb,
  Globe2,
  Bot,
  Zap,
  Trophy,
  BarChart3,
  Star,
  ArrowRight,
} from "lucide-react";
import { list1, list1Categories } from "./data/list1";
import { list2, list2Categories } from "./data/list2";
import { list3, list3Categories } from "./data/list3";
import IdeaListTab from "./components/IdeaListTab";
import TierSection from "./components/TierSection";
import FastCashSection from "./components/FastCashSection";
import PlatformsSection from "./components/PlatformsSection";
import ComparisonTable from "./components/ComparisonTable";
import Navigation, { type NavTab } from "./components/Navigation";
import CommandPalette from "./components/CommandPalette";
import { ToastProvider } from "./components/ToastProvider";
import { ScrollProgress, ScrollToTopButton } from "./components/ScrollUtils";
import { useLocalStorage } from "./hooks/useLocalStorage";
import { FavoritesProvider, useFavorites } from "./context/FavoritesContext";
import { useCountUp } from "./hooks/useCountUp";
import type { Idea, Risk } from "./types";

type TabKey =
  | "overview"
  | "tiers"
  | "list1"
  | "list2"
  | "list3"
  | "fastcash"
  | "platforms"
  | "comparison"
  | "favorites";

const ALL_IDEAS = [...list1, ...list2, ...list3];
const ALL_IDEAS_TAGGED = [
  ...list1.map((i) => ({ ...i, source: "100 Ways (Brainstorm)" })),
  ...list2.map((i) => ({ ...i, source: "100 Internet Hustles" })),
  ...list3.map((i) => ({ ...i, source: "AI OFM & Companion Economy" })),
];
const ALL_CATEGORIES = Array.from(new Set([...list1Categories, ...list2Categories, ...list3Categories]));

function useDarkMode() {
  const [dark, setDark] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    const saved = localStorage.getItem("theme");
    if (saved) return saved === "dark";
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (dark) {
      root.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      root.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [dark]);

  return { dark, setDark };
}

function StatCard({ label, value, accent, suffix = "" }: { label: string; value: number; accent: string; suffix?: string }) {
  const animated = useCountUp(value);
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
      <div className={`text-2xl font-bold tabular-nums ${accent}`}>
        {animated}
        {suffix}
      </div>
      <div className="mt-1 text-xs font-medium text-slate-500 dark:text-slate-400">{label}</div>
    </div>
  );
}

function Overview({ onNavigate }: { onNavigate: (t: TabKey) => void }) {
  const riskCounts = useMemo(() => {
    const counts: Record<Risk, number> = { legit: 0, caution: 0, risky: 0, illegal: 0, info: 0 };
    ALL_IDEAS.forEach((i) => (counts[i.risk] += 1));
    return counts;
  }, []);

  const cards: { key: TabKey; title: string; desc: string; count: string; color: string }[] = [
    {
      key: "tiers",
      title: "🎯 Best-Fit Tier Plan",
      desc: "Every idea filtered specifically for your exact situation, ranked into 7 tiers by real odds.",
      count: "7 tiers · 65 ideas",
      color: "from-indigo-500 to-violet-600",
    },
    {
      key: "list1",
      title: "💡 100 Ways (Original Brainstorm)",
      desc: "The first full brainstorm: freelancing, digital products, content, affiliate, agency & more.",
      count: "100 ideas",
      color: "from-emerald-500 to-teal-600",
    },
    {
      key: "list2",
      title: "🌐 100 'Internet Says' Hustles",
      desc: "Trading, crypto, flipping, AI hype, MLM, bounties, and every grey/illegal hustle the internet pushes.",
      count: "100 ideas",
      color: "from-orange-500 to-amber-600",
    },
    {
      key: "list3",
      title: "🤖 AI OFM & Companion Economy",
      desc: "AI OnlyFans management, virtual personas, companion apps, and the legit creator-tooling side.",
      count: "50 ideas",
      color: "from-fuchsia-500 to-pink-600",
    },
    {
      key: "fastcash",
      title: "⚡ Fast Cash Playbook",
      desc: "The exact ranked answer to 'I need $10-100 fast' — with a real reality check on timing.",
      count: "2 phases",
      color: "from-sky-500 to-blue-600",
    },
    {
      key: "platforms",
      title: "🏆 Platforms & Contests",
      desc: "Every micro-task platform and prize-money contest site named in the conversation.",
      count: "5 platforms · 14 contests",
      color: "from-rose-500 to-red-600",
    },
  ];

  return (
    <div className="space-y-8">
      <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 p-8 text-white shadow-xl dark:border-slate-800 sm:p-10">
        <div className="pointer-events-none absolute inset-0 bg-noise" />
        <div className="pointer-events-none absolute -left-10 -top-10 h-64 w-64 animate-blob rounded-full bg-white/10 blur-3xl" />
        <div className="pointer-events-none absolute -right-10 top-10 h-72 w-72 animate-blob animation-delay-2000 rounded-full bg-fuchsia-300/20 blur-3xl" />
        <div className="pointer-events-none absolute bottom-0 left-1/3 h-56 w-56 animate-blob animation-delay-4000 rounded-full bg-indigo-300/20 blur-3xl" />

        <div className="relative">
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-3 inline-block rounded-full bg-white/15 px-3 py-1 text-xs font-semibold tracking-wide ring-1 ring-white/20"
          >
            EXTRACTED FROM THE FULL CONVERSATION · NOTHING LEFT OUT
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="max-w-2xl text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl"
          >
            The Complete $1K–$10K in Month One Playbook
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-3 max-w-2xl text-sm leading-relaxed text-white/85 sm:text-base"
          >
            Every single idea, tier, platform, and fast-cash tactic mentioned across the entire conversation — organized,
            filtered, risk-tagged, and made searchable. Zero capital. Anonymous. Calculated hard work plus some luck.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="mt-6 flex flex-wrap gap-3"
          >
            <button
              onClick={() => onNavigate("tiers")}
              className="group flex items-center gap-1.5 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-indigo-700 shadow-sm transition hover:bg-indigo-50"
            >
              Start with your best-fit tier plan
              <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
            </button>
            <button
              onClick={() => onNavigate("fastcash")}
              className="rounded-xl bg-white/15 px-4 py-2.5 text-sm font-semibold text-white ring-1 ring-white/30 transition hover:bg-white/25"
            >
              I need cash fast ⚡
            </button>
          </motion.div>
        </div>
      </div>

      <div>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400">Everything, at a glance</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
          <StatCard label="Total ideas catalogued" value={ALL_IDEAS.length} accent="text-slate-800 dark:text-slate-100" />
          <StatCard label="Legit / real" value={riskCounts.legit} accent="text-emerald-600 dark:text-emerald-400" />
          <StatCard label="Grey area / oversold" value={riskCounts.caution} accent="text-amber-600 dark:text-amber-400" />
          <StatCard label="High risk" value={riskCounts.risky} accent="text-orange-600 dark:text-orange-400" />
          <StatCard label="Illegal / scam — avoid" value={riskCounts.illegal} accent="text-red-600 dark:text-red-400" />
        </div>
      </div>

      <div>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400">Jump to a section</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {cards.map((c, idx) => (
            <motion.button
              key={c.key}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * idx }}
              onClick={() => onNavigate(c.key)}
              className="group relative flex flex-col items-start overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
            >
              <div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${c.color}`} />
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">{c.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-500 dark:text-slate-400">{c.desc}</p>
              <span className="mt-3 rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                {c.count}
              </span>
              <span className="mt-3 flex items-center gap-1 text-sm font-semibold text-indigo-600 dark:text-indigo-400">
                View section
                <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-1" />
              </span>
            </motion.button>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5 text-sm leading-relaxed text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
        <b className="text-slate-800 dark:text-slate-200">The honest read from the whole conversation:</b> $1,000 in month
        one is genuinely achievable through hustle. $10,000 in month one is rare and needs either a pre-existing
        skill/portfolio, several closed clients landing in the same window, or a lucky viral moment — plan around the
        median outcome, not the lottery ticket. Use the risk badges throughout this site (
        <span className="font-semibold text-emerald-600 dark:text-emerald-400">Legit</span>,{" "}
        <span className="font-semibold text-amber-600 dark:text-amber-400">Grey Area</span>,{" "}
        <span className="font-semibold text-orange-600 dark:text-orange-400">High Risk</span>,{" "}
        <span className="font-semibold text-red-600 dark:text-red-400">Illegal/Scam</span>) to decide what's actually
        worth your time.
      </div>
    </div>
  );
}

function AppShell() {
  const { dark, setDark } = useDarkMode();
  const [tab, setTab] = useLocalStorage<TabKey>("playbook:tab", "overview");
  const [paletteOpen, setPaletteOpen] = useState(false);
  const { count: favoritesCount } = useFavorites();

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const navTabs: NavTab[] = [
    { key: "overview", label: "Overview", icon: <Home className="h-4 w-4" /> },
    { key: "tiers", label: "Best-Fit Tier Plan", icon: <Target className="h-4 w-4" /> },
    { key: "list1", label: "100 Ways (Brainstorm)", icon: <Lightbulb className="h-4 w-4" /> },
    { key: "list2", label: "100 Internet Hustles", icon: <Globe2 className="h-4 w-4" /> },
    { key: "list3", label: "AI OFM & Companion Economy", icon: <Bot className="h-4 w-4" /> },
    { key: "fastcash", label: "Fast Cash Playbook", icon: <Zap className="h-4 w-4" /> },
    { key: "platforms", label: "Platforms & Contests", icon: <Trophy className="h-4 w-4" /> },
    { key: "comparison", label: "Comparison Table", icon: <BarChart3 className="h-4 w-4" /> },
    { key: "favorites", label: "Saved Ideas", icon: <Star className="h-4 w-4" />, badge: favoritesCount },
  ];

  const handleSelectIdea = (idea: Idea & { source: string }) => {
    const map: Record<string, TabKey> = {
      "100 Ways (Brainstorm)": "list1",
      "100 Internet Hustles": "list2",
      "AI OFM & Companion Economy": "list3",
    };
    setTab(map[idea.source] ?? "overview");
  };

  return (
    <ToastProvider>
      <div className="min-h-screen bg-slate-50 text-slate-900 transition-colors dark:bg-slate-950 dark:text-slate-100">
        <ScrollProgress />
        <Navigation
          tabs={navTabs}
          active={tab}
          onNavigate={(k) => setTab(k as TabKey)}
          dark={dark}
          onToggleDark={() => setDark(!dark)}
          onOpenPalette={() => setPaletteOpen(true)}
        />

        <div className="lg:pl-64">
          <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={tab}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18 }}
              >
                {tab === "overview" && <Overview onNavigate={setTab} />}
                {tab === "tiers" && <TierSection />}
                {tab === "list1" && (
                  <IdeaListTab
                    title="💡 100 Ways — The Original Brainstorm"
                    subtitle="Every idea from the first /brainstorm request: no capital, all day to work, anonymous, month one."
                    ideas={list1}
                    categories={list1Categories}
                  />
                )}
                {tab === "list2" && (
                  <IdeaListTab
                    title="🌐 100 Ways 'The Internet Says' — Trading, Crypto, Hype & Grey Areas"
                    subtitle="The follow-up list: everything ranking online for 'make money now' — flagged for legality and realism."
                    ideas={list2}
                    categories={list2Categories}
                  />
                )}
                {tab === "list3" && (
                  <IdeaListTab
                    title="🤖 AI OFM & Companion Economy — 50 Ideas"
                    subtitle="AI OnlyFans management, virtual personas, companion apps, and the legitimate creator-tooling side."
                    ideas={list3}
                    categories={list3Categories}
                  />
                )}
                {tab === "fastcash" && <FastCashSection />}
                {tab === "platforms" && <PlatformsSection />}
                {tab === "comparison" && <ComparisonTable />}
                {tab === "favorites" && (
                  <IdeaListTab
                    title="⭐ Your Saved Ideas"
                    subtitle="Every idea you've starred across all three lists, in one place."
                    ideas={ALL_IDEAS}
                    categories={ALL_CATEGORIES}
                    favoritesOnlyMode
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </main>

          <footer className="border-t border-slate-200 bg-white py-6 text-center text-xs text-slate-400 dark:border-slate-800 dark:bg-slate-950">
            Compiled directly from the conversation for research/planning purposes. Always verify current legality,
            platform rules, and tax obligations in your jurisdiction before starting anything.
          </footer>
        </div>

        <ScrollToTopButton />
        <CommandPalette
          open={paletteOpen}
          onClose={() => setPaletteOpen(false)}
          ideas={ALL_IDEAS_TAGGED}
          navItems={navTabs.map((t) => ({ key: t.key, label: t.label, icon: "" }))}
          onNavigate={(k) => setTab(k as TabKey)}
          onSelectIdea={handleSelectIdea}
        />
      </div>
    </ToastProvider>
  );
}

export default function App() {
  return (
    <FavoritesProvider>
      <AppShell />
    </FavoritesProvider>
  );
}
