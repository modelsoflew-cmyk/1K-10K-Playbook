export type Risk = "legit" | "caution" | "risky" | "illegal" | "info";

export interface Idea {
  id: string;
  num: number;
  title: string;
  desc: string;
  risk: Risk;
  category: string;
}

export interface ListMeta {
  key: string;
  title: string;
  subtitle: string;
  count: number;
}

export interface TierItem {
  title: string;
  desc: string;
}

export interface Tier {
  id: string;
  name: string;
  label: string;
  color: string;
  speed: string;
  probability: string;
  monthRange: string;
  note: string;
  items: TierItem[];
}
