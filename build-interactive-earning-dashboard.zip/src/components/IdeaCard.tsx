import { motion } from "framer-motion";
import { Star } from "lucide-react";
import type { Idea } from "../types";
import RiskBadge from "./RiskBadge";

interface Props {
  idea: Idea;
  isFavorite: boolean;
  onToggleFavorite: (idea: Idea) => void;
}

export default function IdeaCard({ idea, isFavorite, onToggleFavorite }: Props) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.22 }}
      whileHover={{ y: -4 }}
      className="group relative flex flex-col gap-2 rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-shadow hover:shadow-lg hover:shadow-slate-200/60 dark:border-slate-800 dark:bg-slate-900 dark:hover:shadow-none"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2">
          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-slate-100 text-[11px] font-bold text-slate-500 dark:bg-slate-800 dark:text-slate-400">
            {idea.num}
          </span>
          <h3 className="truncate text-sm font-semibold text-slate-900 dark:text-slate-100">{idea.title}</h3>
        </div>
        <button
          onClick={() => onToggleFavorite(idea)}
          aria-label="Toggle favorite"
          className="shrink-0 rounded-md p-1 text-slate-300 transition hover:bg-amber-50 hover:text-amber-400 dark:text-slate-600 dark:hover:bg-amber-500/10"
        >
          <Star className={`h-4 w-4 transition ${isFavorite ? "fill-amber-400 text-amber-400" : ""}`} />
        </button>
      </div>
      <p className="text-sm leading-relaxed text-slate-500 dark:text-slate-400">{idea.desc}</p>
      <div className="mt-1 flex flex-wrap items-center justify-between gap-2">
        <span className="inline-block w-fit rounded-full bg-indigo-50 px-2 py-0.5 text-[11px] font-medium text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300">
          {idea.category}
        </span>
        <RiskBadge risk={idea.risk} />
      </div>
    </motion.div>
  );
}
