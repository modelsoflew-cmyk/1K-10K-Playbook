import { Search, Star } from "lucide-react";
import type { Risk } from "../types";

interface Props {
  search: string;
  onSearch: (v: string) => void;
  risk: Risk | "all";
  onRisk: (v: Risk | "all") => void;
  category: string;
  onCategory: (v: string) => void;
  categories: string[];
  count: number;
  total: number;
  favoritesOnly?: boolean;
  onToggleFavoritesOnly?: () => void;
}

const RISK_FILTERS: { key: Risk | "all"; label: string }[] = [
  { key: "all", label: "All" },
  { key: "legit", label: "Legit" },
  { key: "caution", label: "Grey Area" },
  { key: "risky", label: "High Risk" },
  { key: "illegal", label: "Illegal / Scam" },
];

export default function FilterBar({
  search,
  onSearch,
  risk,
  onRisk,
  category,
  onCategory,
  categories,
  count,
  total,
  favoritesOnly,
  onToggleFavoritesOnly,
}: Props) {
  return (
    <div className="sticky top-14 z-10 mb-6 flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white/80 p-4 shadow-sm backdrop-blur-xl dark:border-slate-800 dark:bg-slate-900/70 sm:flex-row sm:items-center sm:justify-between lg:top-4">
      <div className="flex flex-1 flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={search}
            onChange={(e) => onSearch(e.target.value)}
            placeholder="Search ideas..."
            className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm text-slate-700 outline-none ring-indigo-500/30 transition placeholder:text-slate-400 focus:ring-2 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          />
        </div>
        <select
          value={category}
          onChange={(e) => onCategory(e.target.value)}
          className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none ring-indigo-500/30 transition focus:ring-2 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 sm:w-56"
        >
          <option value="all">All categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        {onToggleFavoritesOnly && (
          <button
            onClick={onToggleFavoritesOnly}
            className={`flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium transition ${
              favoritesOnly
                ? "bg-amber-400 text-amber-950 shadow-sm"
                : "bg-slate-100 text-slate-500 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
            }`}
          >
            <Star className={`h-3.5 w-3.5 ${favoritesOnly ? "fill-amber-950" : ""}`} />
            Saved only
          </button>
        )}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        {RISK_FILTERS.map((r) => (
          <button
            key={r.key}
            onClick={() => onRisk(r.key)}
            className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
              risk === r.key
                ? "bg-indigo-600 text-white shadow-sm"
                : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
            }`}
          >
            {r.label}
          </button>
        ))}
        <span className="ml-1 shrink-0 text-xs font-medium text-slate-400">
          {count}/{total}
        </span>
      </div>
    </div>
  );
}
