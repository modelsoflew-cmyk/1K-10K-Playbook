import { ShieldCheck, AlertTriangle, ShieldAlert, Ban, Info } from "lucide-react";
import type { Risk } from "../types";

const RISK_CONFIG: Record<Risk, { label: string; classes: string; Icon: typeof ShieldCheck }> = {
  legit: {
    label: "Legit",
    classes:
      "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/30",
    Icon: ShieldCheck,
  },
  caution: {
    label: "Grey Area",
    classes:
      "bg-amber-50 text-amber-700 ring-1 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/30",
    Icon: AlertTriangle,
  },
  risky: {
    label: "High Risk",
    classes:
      "bg-orange-50 text-orange-700 ring-1 ring-orange-200 dark:bg-orange-500/10 dark:text-orange-300 dark:ring-orange-500/30",
    Icon: ShieldAlert,
  },
  illegal: {
    label: "Illegal / Scam",
    classes:
      "bg-red-50 text-red-700 ring-1 ring-red-200 dark:bg-red-500/10 dark:text-red-300 dark:ring-red-500/30",
    Icon: Ban,
  },
  info: {
    label: "Info",
    classes:
      "bg-sky-50 text-sky-700 ring-1 ring-sky-200 dark:bg-sky-500/10 dark:text-sky-300 dark:ring-sky-500/30",
    Icon: Info,
  },
};

export default function RiskBadge({ risk }: { risk: Risk }) {
  const cfg = RISK_CONFIG[risk];
  const { Icon } = cfg;
  return (
    <span
      className={`inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium whitespace-nowrap ${cfg.classes}`}
    >
      <Icon className="h-3 w-3" strokeWidth={2.5} />
      {cfg.label}
    </span>
  );
}

export { RISK_CONFIG };
