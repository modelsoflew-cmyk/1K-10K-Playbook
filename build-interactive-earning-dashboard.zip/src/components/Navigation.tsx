import { useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X, Sun, Moon, Search, Sparkles } from "lucide-react";

export interface NavTab {
  key: string;
  label: string;
  icon: ReactNode;
  badge?: number;
}

interface Props {
  tabs: NavTab[];
  active: string;
  onNavigate: (key: string) => void;
  dark: boolean;
  onToggleDark: () => void;
  onOpenPalette: () => void;
}

export default function Navigation({ tabs, active, onNavigate, dark, onToggleDark, onOpenPalette }: Props) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const NavButton = ({ tab, onClick }: { tab: NavTab; onClick: () => void }) => {
    const isActive = active === tab.key;
    return (
      <button
        onClick={onClick}
        className={`group relative flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
          isActive
            ? "bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-500/25"
            : "text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100"
        }`}
      >
        <span className={`shrink-0 ${isActive ? "text-white" : "text-slate-400 group-hover:text-indigo-500"}`}>
          {tab.icon}
        </span>
        <span className="flex-1 text-left">{tab.label}</span>
        {typeof tab.badge === "number" && tab.badge > 0 && (
          <span
            className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
              isActive ? "bg-white/20 text-white" : "bg-indigo-100 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-300"
            }`}
          >
            {tab.badge}
          </span>
        )}
      </button>
    );
  };

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-slate-200 bg-white/80 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-950/80 lg:flex">
        <div className="flex items-center gap-2.5 px-5 py-5">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-fuchsia-600 text-lg shadow-lg shadow-indigo-500/30">
            💸
          </span>
          <div>
            <div className="text-sm font-bold leading-tight text-slate-900 dark:text-slate-100">1K–10K Playbook</div>
            <div className="text-[11px] leading-tight text-slate-400">Month One · Zero Capital</div>
          </div>
        </div>

        <button
          onClick={onOpenPalette}
          className="mx-3 mb-3 flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-400 transition hover:border-indigo-200 hover:text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:hover:text-slate-300"
        >
          <Search className="h-3.5 w-3.5" />
          <span className="flex-1 text-left">Search everything...</span>
          <kbd className="rounded border border-slate-200 bg-white px-1 text-[10px] dark:border-slate-700 dark:bg-slate-800">
            ⌘K
          </kbd>
        </button>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3">
          {tabs.map((tab) => (
            <NavButton key={tab.key} tab={tab} onClick={() => onNavigate(tab.key)} />
          ))}
        </nav>

        <div className="border-t border-slate-100 p-3 dark:border-slate-800">
          <button
            onClick={onToggleDark}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-500 transition hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            {dark ? "Light mode" : "Dark mode"}
          </button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-slate-200 bg-white/90 px-4 py-3 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-950/90 lg:hidden">
        <button onClick={() => setDrawerOpen(true)} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800">
          <Menu className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 to-fuchsia-600 text-sm shadow-sm">
            💸
          </span>
          <span className="text-sm font-bold text-slate-900 dark:text-slate-100">1K–10K Playbook</span>
        </div>
        <div className="flex items-center gap-1.5">
          <button onClick={onOpenPalette} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800">
            <Search className="h-5 w-5" />
          </button>
          <button onClick={onToggleDark} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800">
            {dark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
        </div>
      </header>

      {/* Mobile drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDrawerOpen(false)}
              className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-sm lg:hidden"
            />
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "tween", duration: 0.22 }}
              className="fixed inset-y-0 left-0 z-50 flex w-72 flex-col bg-white p-4 shadow-2xl dark:bg-slate-950 lg:hidden"
            >
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-indigo-500" />
                  <span className="text-sm font-bold text-slate-900 dark:text-slate-100">Navigate</span>
                </div>
                <button onClick={() => setDrawerOpen(false)} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <nav className="flex-1 space-y-1 overflow-y-auto">
                {tabs.map((tab) => (
                  <NavButton
                    key={tab.key}
                    tab={tab}
                    onClick={() => {
                      onNavigate(tab.key);
                      setDrawerOpen(false);
                    }}
                  />
                ))}
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
