import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, Gauge, TrendingUp, DollarSign } from "lucide-react";
import { tiers } from "../data/tiers";

const COLOR_MAP: Record<string, { ring: string; text: string; bg: string; badge: string }> = {
  emerald: {
    ring: "ring-emerald-200 dark:ring-emerald-500/30",
    text: "text-emerald-700 dark:text-emerald-300",
    bg: "bg-emerald-50 dark:bg-emerald-500/10",
    badge: "bg-gradient-to-br from-emerald-400 to-emerald-600",
  },
  sky: {
    ring: "ring-sky-200 dark:ring-sky-500/30",
    text: "text-sky-700 dark:text-sky-300",
    bg: "bg-sky-50 dark:bg-sky-500/10",
    badge: "bg-gradient-to-br from-sky-400 to-sky-600",
  },
  violet: {
    ring: "ring-violet-200 dark:ring-violet-500/30",
    text: "text-violet-700 dark:text-violet-300",
    bg: "bg-violet-50 dark:bg-violet-500/10",
    badge: "bg-gradient-to-br from-violet-400 to-violet-600",
  },
  amber: {
    ring: "ring-amber-200 dark:ring-amber-500/30",
    text: "text-amber-700 dark:text-amber-300",
    bg: "bg-amber-50 dark:bg-amber-500/10",
    badge: "bg-gradient-to-br from-amber-400 to-amber-600",
  },
  rose: {
    ring: "ring-rose-200 dark:ring-rose-500/30",
    text: "text-rose-700 dark:text-rose-300",
    bg: "bg-rose-50 dark:bg-rose-500/10",
    badge: "bg-gradient-to-br from-rose-400 to-rose-600",
  },
  slate: {
    ring: "ring-slate-200 dark:ring-slate-500/30",
    text: "text-slate-700 dark:text-slate-300",
    bg: "bg-slate-50 dark:bg-slate-500/10",
    badge: "bg-gradient-to-br from-slate-400 to-slate-600",
  },
  fuchsia: {
    ring: "ring-fuchsia-200 dark:ring-fuchsia-500/30",
    text: "text-fuchsia-700 dark:text-fuchsia-300",
    bg: "bg-fuchsia-50 dark:bg-fuchsia-500/10",
    badge: "bg-gradient-to-br from-fuchsia-400 to-fuchsia-600",
  },
};

export default function TierSection() {
  const [open, setOpen] = useState<Record<string, boolean>>({ tier1: true });

  const toggle = (id: string) => setOpen((prev) => ({ ...prev, [id]: !prev[id] }));

  return (
    <div className="space-y-5">
      <div className="rounded-2xl border border-indigo-200 bg-indigo-50/70 p-5 dark:border-indigo-500/30 dark:bg-indigo-500/10">
        <h2 className="text-lg font-semibold text-indigo-900 dark:text-indigo-200">
          Filtered specifically for: Sri Lankan · 18 · no capital · laptop + phone · fast internet · no face, no voice
        </h2>
        <p className="mt-1 text-sm leading-relaxed text-indigo-800/80 dark:text-indigo-200/80">
          This is every idea from the full conversation that survives that exact filter, ranked into 7 tiers by realistic
          odds of hitting $1,000–$10,000 in the first month with calculated hard work and some luck.
        </p>
      </div>

      {tiers.map((tier, idx) => {
        const c = COLOR_MAP[tier.color];
        const isOpen = !!open[tier.id];
        return (
          <motion.div
            key={tier.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.03 }}
            className={`overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm ring-1 ring-inset dark:border-slate-800 dark:bg-slate-900 ${c.ring}`}
          >
            <button
              onClick={() => toggle(tier.id)}
              className="flex w-full items-center justify-between gap-4 p-5 text-left transition hover:bg-slate-50/70 dark:hover:bg-slate-800/40"
            >
              <div className="flex items-center gap-3">
                <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-sm font-bold text-white shadow-sm ${c.badge}`}>
                  {tier.name.replace("Tier ", "T")}
                </span>
                <div>
                  <h3 className="font-semibold text-slate-900 dark:text-slate-100">{tier.label}</h3>
                  <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
                    <span className="flex items-center gap-1">
                      <Gauge className="h-3 w-3" /> {tier.speed}
                    </span>
                    <span className="flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" /> {tier.probability}
                    </span>
                    <span className="flex items-center gap-1">
                      <DollarSign className="h-3 w-3" /> {tier.monthRange}
                    </span>
                  </div>
                </div>
              </div>
              <motion.span animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
                <ChevronDown className="h-5 w-5 shrink-0 text-slate-400" />
              </motion.span>
            </button>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.22 }}
                >
                  <div className="border-t border-slate-100 p-5 dark:border-slate-800">
                    <p className={`mb-4 rounded-lg p-3 text-sm leading-relaxed ${c.bg} ${c.text}`}>{tier.note}</p>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {tier.items.map((item, i) => (
                        <div
                          key={i}
                          className="rounded-lg border border-slate-100 bg-slate-50/60 p-3 transition hover:border-slate-200 hover:bg-white dark:border-slate-800 dark:bg-slate-800/40 dark:hover:bg-slate-800"
                        >
                          <div className="text-sm font-medium text-slate-800 dark:text-slate-100">{item.title}</div>
                          {item.desc && (
                            <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{item.desc}</div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        );
      })}
    </div>
  );
}
