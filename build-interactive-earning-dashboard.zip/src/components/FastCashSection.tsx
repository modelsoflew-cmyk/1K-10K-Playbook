import { motion } from "framer-motion";
import { Zap, AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import { fastCashPhases, fastCashRealityCheck, todaysActionPlan } from "../data/fastcash";
import RiskBadge from "./RiskBadge";

export default function FastCashSection() {
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
      >
        <div className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 text-amber-500 dark:bg-amber-500/10">
            <Zap className="h-5 w-5" />
          </span>
          <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">"I need $10–$100 fast" Playbook</h2>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-slate-500 dark:text-slate-400">
          Straight from the conversation: the real speed ranking when you want cash now, not a new business idea.
        </p>
      </motion.div>

      {fastCashPhases.map((phase, pIdx) => (
        <motion.div
          key={phase.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 * (pIdx + 1) }}
          className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
        >
          <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">{phase.title}</h3>
          <p className="mt-1 mb-4 text-sm leading-relaxed text-slate-500 dark:text-slate-400">{phase.intro}</p>
          <div className="space-y-3">
            {phase.steps.map((step, i) => (
              <div
                key={i}
                className="rounded-xl border border-slate-100 bg-slate-50/60 p-4 transition hover:border-slate-200 hover:bg-white dark:border-slate-800 dark:bg-slate-800/40 dark:hover:bg-slate-800"
              >
                <div className="mb-1 flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-100">{step.title}</h4>
                  <div className="flex items-center gap-2">
                    <span className="flex items-center gap-1 rounded-full bg-indigo-50 px-2 py-0.5 text-[11px] font-medium text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300">
                      <Clock className="h-3 w-3" />
                      {step.timing}
                    </span>
                    <RiskBadge risk={step.tag} />
                  </div>
                </div>
                <p className="text-sm leading-relaxed text-slate-500 dark:text-slate-400">{step.desc}</p>
              </div>
            ))}
          </div>
        </motion.div>
      ))}

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-red-200 bg-red-50/70 p-5 dark:border-red-500/30 dark:bg-red-500/10"
      >
        <h3 className="mb-1 flex items-center gap-1.5 text-sm font-semibold text-red-800 dark:text-red-300">
          <AlertTriangle className="h-4 w-4" /> Reality Check
        </h3>
        <p className="text-sm leading-relaxed text-red-700/90 dark:text-red-300/80">{fastCashRealityCheck}</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-5 dark:border-emerald-500/30 dark:bg-emerald-500/10"
      >
        <h3 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-emerald-800 dark:text-emerald-300">
          <CheckCircle2 className="h-4 w-4" /> What To Do In The Next Hour
        </h3>
        <ol className="list-inside list-decimal space-y-1.5 text-sm leading-relaxed text-emerald-800/90 dark:text-emerald-200/90">
          {todaysActionPlan.map((step, i) => (
            <li key={i}>{step}</li>
          ))}
        </ol>
      </motion.div>
    </div>
  );
}
