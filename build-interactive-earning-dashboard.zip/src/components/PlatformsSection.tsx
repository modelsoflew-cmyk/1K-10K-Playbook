import { useState } from "react";
import { motion } from "framer-motion";
import { ListChecks, Trophy } from "lucide-react";
import { microtaskPlatforms, contestSites } from "../data/platforms";
import RiskBadge from "./RiskBadge";

export default function PlatformsSection() {
  const [contestFilter, setContestFilter] = useState("all");
  const categories = Array.from(new Set(contestSites.map((c) => c.category)));
  const filteredContests =
    contestFilter === "all" ? contestSites : contestSites.filter((c) => c.category === contestFilter);

  return (
    <div className="space-y-8">
      <div>
        <div className="mb-4 flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-50 text-sky-600 dark:bg-sky-500/10 dark:text-sky-300">
            <ListChecks className="h-5 w-5" />
          </span>
          <div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">Micro-Task Platforms</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Sign-up-today platforms where the platform trusts itself, so you don't need reviews or a portfolio first.
            </p>
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {microtaskPlatforms.map((p, idx) => (
            <motion.div
              key={p.name}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.04 }}
              className="rounded-xl border border-slate-200 bg-white p-4 transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
            >
              <div className="mb-1.5 flex items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-100">{p.name}</h3>
                <RiskBadge risk={p.tag} />
              </div>
              <p className="text-sm leading-relaxed text-slate-500 dark:text-slate-400">{p.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>

      <div>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-300">
              <Trophy className="h-5 w-5" />
            </span>
            <div>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                Contest Sites (Prize Money Already Exists)
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                You compete for money the client already committed — no client trust-building needed first.
              </p>
            </div>
          </div>
          <select
            value={contestFilter}
            onChange={(e) => setContestFilter(e.target.value)}
            className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none ring-indigo-500/30 transition focus:ring-2 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <option value="all">All categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredContests.map((c, idx) => (
            <motion.div
              key={c.name}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.03 }}
              className="rounded-xl border border-slate-200 bg-white p-4 transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
            >
              <div className="mb-1.5 flex items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-100">{c.name}</h3>
                <span className="rounded-full bg-indigo-50 px-2 py-0.5 text-[10px] font-medium text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300">
                  {c.category}
                </span>
              </div>
              <p className="text-sm leading-relaxed text-slate-500 dark:text-slate-400">{c.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
