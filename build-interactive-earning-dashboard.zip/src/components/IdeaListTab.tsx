import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { PackageOpen } from "lucide-react";
import type { Idea, Risk } from "../types";
import FilterBar from "./FilterBar";
import IdeaCard from "./IdeaCard";
import { useDebounce } from "../hooks/useDebounce";
import { useFavorites } from "../context/FavoritesContext";
import { useToast } from "./ToastProvider";

interface Props {
  title: string;
  subtitle: string;
  ideas: Idea[];
  categories: string[];
  favoritesOnlyMode?: boolean;
}

export default function IdeaListTab({ title, subtitle, ideas, categories, favoritesOnlyMode }: Props) {
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounce(search, 200);
  const [risk, setRisk] = useState<Risk | "all">("all");
  const [category, setCategory] = useState("all");
  const [favoritesOnly, setFavoritesOnly] = useState(!!favoritesOnlyMode);
  const { isFavorite, toggleFavorite } = useFavorites();
  const { push } = useToast();

  const filtered = useMemo(() => {
    return ideas.filter((idea) => {
      const matchesSearch =
        debouncedSearch.trim() === "" ||
        idea.title.toLowerCase().includes(debouncedSearch.toLowerCase()) ||
        idea.desc.toLowerCase().includes(debouncedSearch.toLowerCase());
      const matchesRisk = risk === "all" || idea.risk === risk;
      const matchesCategory = category === "all" || idea.category === category;
      const matchesFavorite = !favoritesOnly || isFavorite(idea.id);
      return matchesSearch && matchesRisk && matchesCategory && matchesFavorite;
    });
  }, [ideas, debouncedSearch, risk, category, favoritesOnly, isFavorite]);

  const handleToggleFavorite = (idea: Idea) => {
    const wasFavorite = isFavorite(idea.id);
    toggleFavorite(idea.id);
    push(wasFavorite ? `Removed "${idea.title}"` : `Saved "${idea.title}"`, "star");
  };

  return (
    <div>
      <div className="mb-5">
        <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">{title}</h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{subtitle}</p>
      </div>
      <FilterBar
        search={search}
        onSearch={setSearch}
        risk={risk}
        onRisk={setRisk}
        category={category}
        onCategory={setCategory}
        categories={categories}
        count={filtered.length}
        total={ideas.length}
        favoritesOnly={favoritesOnly}
        onToggleFavoritesOnly={!favoritesOnlyMode ? () => setFavoritesOnly((v) => !v) : undefined}
      />
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-slate-300 p-14 text-center dark:border-slate-700">
          <PackageOpen className="h-8 w-8 text-slate-300 dark:text-slate-600" />
          <p className="text-sm text-slate-400">
            {favoritesOnly ? "No saved ideas yet — tap the star on any card to save it here." : "No ideas match your filters."}
          </p>
        </div>
      ) : (
        <motion.div layout className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {filtered.map((idea) => (
              <IdeaCard
                key={idea.id}
                idea={idea}
                isFavorite={isFavorite(idea.id)}
                onToggleFavorite={handleToggleFavorite}
              />
            ))}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  );
}
