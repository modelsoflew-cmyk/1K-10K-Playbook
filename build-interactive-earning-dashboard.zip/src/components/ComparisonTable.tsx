import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpDown, LayoutGrid } from "lucide-react";
import { tiers } from "../data/tiers";

const COLOR_CLASSES: Record<string, string> = {
  emerald: "bg-emerald-500",
  sky: "bg-sky-500",
  violet: "bg-violet-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  slate: "bg-slate-500",
  fuchsia: "bg-fuchsia-500",
};

// Rough visual weight per tier for the odds bar (1-5), purely illustrative of relative ranking
const ODDS_WEIGHT: Record<string, number> = {
  tier1: 5,
  tier2: 4,
  tier6: 4,
  tier3: 3,
  tier7: 3,
  tier4: 2,
  tier5: 2,
};

export default function ComparisonTable() {
  const [sortKey, setSortKey] = useState<"default" | "probability">("default");

  const rows =
    sortKey === "default"
      ? tiers
      : [...tiers].sort((a, b) => (ODDS_WEIGHT[b.id] ?? 0) - (ODDS_WEIGHT[a.id] ?? 0));

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
      >
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300">
              <LayoutGrid className="h-5 w-5" />
            </span>
            <div>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">Tier Comparison Table</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Every tier from the filtered plan, side by side — speed, odds, and realistic month-1 payout.
              </p>
            </div>
          </div>
          <button
            onClick={() => setSortKey(sortKey === "default" ? "probability" : "default")}
            className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-600 transition hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
          >
            <ArrowUpDown className="h-3.5 w-3.5" />
            Sort: {sortKey === "default" ? "Recommended order" : "Best odds first"}
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-400 dark:border-slate-800">
                <th className="py-2 pr-4 font-medium">Tier</th>
                <th className="py-2 pr-4 font-medium">Speed to Cash</th>
                <th className="py-2 pr-4 font-medium">Odds of Hitting Target</th>
                <th className="py-2 pr-4 font-medium">Realistic Month-1 Range</th>
                <th className="py-2 pr-4 font-medium"># Ideas</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((t) => (
                <tr key={t.id} className="border-b border-slate-100 align-top last:border-0 dark:border-slate-800/70">
                  <td className="py-3 pr-4">
                    <div className="flex items-center gap-2">
                      <span className={`h-2.5 w-2.5 rounded-full ${COLOR_CLASSES[t.color]}`} />
                      <div>
                        <div className="font-semibold text-slate-800 dark:text-slate-100">{t.name}</div>
                        <div className="text-xs text-slate-400">{t.label}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 pr-4 text-slate-600 dark:text-slate-300">{t.speed}</td>
                  <td className="py-3 pr-4">
                    <div className="mb-1 text-slate-600 dark:text-slate-300">{t.probability}</div>
                    <div className="h-1.5 w-28 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                      <div
                        className={`h-full rounded-full ${COLOR_CLASSES[t.color]}`}
                        style={{ width: `${(ODDS_WEIGHT[t.id] ?? 3) * 20}%` }}
                      />
                    </div>
                  </td>
                  <td className="py-3 pr-4 font-medium text-slate-700 dark:text-slate-200">{t.monthRange}</td>
                  <td className="py-3 pr-4 text-slate-600 dark:text-slate-300">{t.items.length}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      <div className="grid gap-4 md:grid-cols-2">
        {tiers.map((t, idx) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.03 }}
            className="rounded-2xl border border-slate-200 bg-white p-5 transition hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
          >
            <div className="mb-2 flex items-center gap-2">
              <span className={`h-2.5 w-2.5 rounded-full ${COLOR_CLASSES[t.color]}`} />
              <h3 className="font-semibold text-slate-800 dark:text-slate-100">
                {t.name} — {t.label}
              </h3>
            </div>
            <p className="text-sm leading-relaxed text-slate-500 dark:text-slate-400">{t.note}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
