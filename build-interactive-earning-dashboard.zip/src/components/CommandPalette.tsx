import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, ArrowRight, CornerDownLeft, Compass, ArrowUpDown } from "lucide-react";
import type { Idea } from "../types";
import RiskBadge from "./RiskBadge";

interface NavItem {
  key: string;
  label: string;
  icon: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  ideas: (Idea & { source: string })[];
  navItems: NavItem[];
  onNavigate: (key: string) => void;
  onSelectIdea: (idea: Idea & { source: string }) => void;
}

type Result =
  | { type: "nav"; key: string; label: string }
  | { type: "idea"; key: string; idea: Idea & { source: string } };

export default function CommandPalette({ open, onClose, ideas, navItems, onNavigate, onSelectIdea }: Props) {
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setQuery("");
      setActiveIndex(0);
      setTimeout(() => inputRef.current?.focus(), 30);
    }
  }, [open]);

  const matchedIdeas = useMemo(() => {
    if (query.trim().length < 2) return [];
    const q = query.toLowerCase();
    return ideas.filter((i) => i.title.toLowerCase().includes(q) || i.desc.toLowerCase().includes(q)).slice(0, 8);
  }, [ideas, query]);

  const matchedNav = useMemo(() => {
    if (!query.trim()) return navItems;
    const q = query.toLowerCase();
    return navItems.filter((n) => n.label.toLowerCase().includes(q));
  }, [navItems, query]);

  const results: Result[] = useMemo(() => {
    const navResults: Result[] = matchedNav.map((n) => ({ type: "nav", key: n.key, label: n.label }));
    const ideaResults: Result[] =
      query.trim().length >= 2 ? matchedIdeas.map((idea) => ({ type: "idea", key: idea.id, idea })) : [];
    return [...navResults, ...ideaResults];
  }, [matchedNav, matchedIdeas, query]);

  useEffect(() => {
    setActiveIndex(0);
  }, [query]);

  const selectResult = (result: Result | undefined) => {
    if (!result) return;
    if (result.type === "nav") {
      onNavigate(result.key);
    } else {
      onSelectIdea(result.idea);
    }
    onClose();
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
        return;
      }
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveIndex((i) => Math.min(i + 1, Math.max(results.length - 1, 0)));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveIndex((i) => Math.max(i - 1, 0));
      } else if (e.key === "Enter") {
        e.preventDefault();
        selectResult(results[activeIndex]);
      }
    };
    if (open) window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose, onNavigate, onSelectIdea, results, activeIndex]);

  useEffect(() => {
    const activeEl = listRef.current?.querySelector('[data-active="true"]');
    activeEl?.scrollIntoView({ block: "nearest" });
  }, [activeIndex]);

  let runningIndex = -1;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[90] flex items-start justify-center bg-slate-900/50 p-4 pt-[10vh] backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.97 }}
            transition={{ duration: 0.15 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-900"
          >
            <div className="flex items-center gap-3 border-b border-slate-100 px-4 py-3 dark:border-slate-800">
              <Search className="h-4 w-4 shrink-0 text-slate-400" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search all 250+ ideas, or jump to a section..."
                className="w-full bg-transparent text-sm text-slate-800 outline-none placeholder:text-slate-400 dark:text-slate-100"
              />
              <kbd className="hidden shrink-0 rounded-md border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[10px] font-medium text-slate-400 dark:border-slate-700 dark:bg-slate-800 sm:block">
                ESC
              </kbd>
            </div>

            <div ref={listRef} className="max-h-[60vh] overflow-y-auto p-2">
              {results.length === 0 && (
                <div className="px-3 py-10 text-center text-sm text-slate-400">
                  {query.trim().length >= 2 ? `No results match "${query}"` : "No matching sections"}
                </div>
              )}

              {matchedNav.length > 0 && (
                <div className="mb-1">
                  <div className="px-2 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                    Sections
                  </div>
                  {matchedNav.map((n) => {
                    runningIndex += 1;
                    const isActive = runningIndex === activeIndex;
                    return (
                      <button
                        key={n.key}
                        data-active={isActive}
                        onMouseEnter={() => setActiveIndex(runningIndex)}
                        onClick={() => selectResult({ type: "nav", key: n.key, label: n.label })}
                        className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-left text-sm transition-colors ${
                          isActive
                            ? "bg-indigo-50 text-indigo-700 dark:bg-slate-800 dark:text-indigo-300"
                            : "text-slate-700 dark:text-slate-200"
                        }`}
                      >
                        <Compass className="h-4 w-4 text-slate-400" />
                        <span className="flex-1">{n.label}</span>
                        <ArrowRight className="h-3.5 w-3.5 text-slate-300" />
                      </button>
                    );
                  })}
                </div>
              )}

              {query.trim().length >= 2 && (
                <div>
                  <div className="px-2 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                    Ideas {matchedIdeas.length > 0 ? `(${matchedIdeas.length})` : ""}
                  </div>
                  {matchedIdeas.map((idea) => {
                    runningIndex += 1;
                    const isActive = runningIndex === activeIndex;
                    return (
                      <button
                        key={idea.id}
                        data-active={isActive}
                        onMouseEnter={() => setActiveIndex(runningIndex)}
                        onClick={() => selectResult({ type: "idea", key: idea.id, idea })}
                        className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-left transition-colors ${
                          isActive ? "bg-indigo-50 dark:bg-slate-800" : ""
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-medium text-slate-700 dark:text-slate-200">
                            {idea.title}
                          </div>
                          <div className="text-[11px] text-slate-400">{idea.source}</div>
                        </div>
                        <RiskBadge risk={idea.risk} />
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="flex items-center gap-4 border-t border-slate-100 px-4 py-2 text-[11px] text-slate-400 dark:border-slate-800">
              <span className="flex items-center gap-1">
                <ArrowUpDown className="h-3 w-3" /> navigate
              </span>
              <span className="flex items-center gap-1">
                <CornerDownLeft className="h-3 w-3" /> select
              </span>
              <span className="hidden sm:inline">Type to search across every list</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
