import type { Risk } from "../types";

export interface FastCashStep {
  title: string;
  desc: string;
  timing: string;
  tag: Risk;
}

export interface FastCashPhase {
  id: string;
  title: string;
  intro: string;
  steps: FastCashStep[];
}

// Source: "how do I make $100 fast" + "fastest path to $10-100, whatever, no existing business" threads
export const fastCashPhases: FastCashPhase[] = [
  {
    id: "phaseA",
    title: "Phase A — If You Have Any Existing Skill, Service or Client Base",
    intro:
      "Don't reach for a brand-new idea — reach for the fastest already-working lever you have. If you've built anything before (a service, a portfolio piece, a local hustle), this is the ranking by real speed.",
    steps: [
      {
        title: "1. Close deals with an existing or local client base",
        desc: "If you already have a working script, objection-handling process, or an advance-payment structure that converts, this is genuinely the fastest lever — the 'trust gap' is already solved because you're talking to people directly, in person or by phone/WhatsApp, in your own language. Money lands directly, no platform verification wait, no algorithm, no stranger trusting a zero-review profile.",
        timing: "Same day / next day",
        tag: "legit",
      },
      {
        title: "2. Enter paid design/logo/writing contests",
        desc: "Contests on Freelancer.com or 99designs pay out same-day if you win, because the client already committed the prize money upfront. You're not waiting to be discovered — you're one of many entries competing for money that's already sitting there. Submit to 5-10 contests for volume.",
        timing: "Payout within days of contest close",
        tag: "legit",
      },
      {
        title: "3. Sell something you've already built",
        desc: "Package any finished asset sitting on your laptop (a template, a landing page, an invoice system) and list it for a low, fast-impulse price ($15-25) on Gumroad. Won't hit $100 alone immediately, but it's a zero-effort listing since the work already exists.",
        timing: "Can sell passively while you do other things",
        tag: "legit",
      },
    ],
  },
  {
    id: "phaseB",
    title: "Phase B — Starting From Absolute Zero (No Accounts, No Business)",
    intro:
      "The honest constraint: almost everything that pays same-day requires either an existing account with history, or a task platform that doesn't need trust to be built first. With zero accounts anywhere yet, your fastest path is task-based micro-work, not client sales — because nobody has to trust you first, the platform already trusts itself. Realistic first payout: 3-10 days, not hours.",
    steps: [
      {
        title: "1. Remotasks or Appen / CrowdGen (data labeling)",
        desc: "Sign up, pass a short qualification test, start earning per task the same day. Withdrawal usually takes a few days to a week depending on payout threshold and method.",
        timing: "Start today, paid in ~3-10 days",
        tag: "legit",
      },
      {
        title: "2. UserTesting.com",
        desc: "Record yourself using a website/app while thinking out loud (screen + voice, not face). Pays ~$4-10 per 15-20 min test. Approval for a new account can take a few days.",
        timing: "Approval days, then per-test payout",
        tag: "legit",
      },
      {
        title: "3. Freelancer.com contests",
        desc: "Logo/mockup/writing contests with prize money already committed by the client. Submit today; payout only if you win, usually within a week of contest close.",
        timing: "Submit today, win-dependent",
        tag: "legit",
      },
      {
        title: "4. Fiverr/Upwork instant-deliverable gig",
        desc: "Post a gig for something you can finish in an hour (simple Canva design, basic HTML page, data cleanup). New accounts have a real discovery lag though — first order commonly takes 1-3 weeks without reviews yet. Post today anyway to start the discovery clock.",
        timing: "1-3 weeks to first order (start the clock now)",
        tag: "caution",
      },
    ],
  },
];

export const fastCashRealityCheck =
  "Nothing legitimate reliably turns $0 and zero accounts into cash in your hand within hours. Every platform above needs signup time, sometimes ID verification, and payout processing (2-7 days typically). If something online promises literal same-day payout with zero setup and no trust-building, that's the exact shape of the scam category: 'cash app flipping', fake investment apps, click farms. Those aren't a faster path — they're a way to lose the little you have.";

export const todaysActionPlan = [
  "Sign up for Remotasks AND CrowdGen/Appen right now — get through onboarding and qualification tasks today so you're not still in the queue when day 3 hits.",
  "Submit to 5+ Freelancer.com contests today — this is the one with real upside if you win, and it costs nothing but time.",
  "Post 1-2 Fiverr/Upwork gigs for something fast to deliver (basic design, data cleanup, a simple HTML page) — even with zero reviews, getting the listing live today starts the discovery clock instead of losing another day.",
];
