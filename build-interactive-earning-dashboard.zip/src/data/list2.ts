import type { Idea } from "../types";

// Source: "the internet says there are ways" — 100 hustles with legitimacy/risk flags
const raw: [number, string, string, string][] = [
  [1, "Day trading forex", "Trade currency pairs for profit — real skill required, high loss rate for beginners.", "risky"],
  [2, "Day trading crypto futures/leverage", "Leveraged crypto trading — amplifies both gains and losses fast.", "risky"],
  [3, "Prop firm challenges (FTMO-style)", "Pay a fee to 'prove' your trading skill and trade a firm's capital — most challengers fail the evaluation.", "risky"],
  [4, "Options wheel strategy", "A structured options income strategy — needs real capital and market knowledge.", "risky"],
  [5, "Copy trading", "Mirror a 'pro' trader's positions automatically — you're trusting someone else's risk management.", "risky"],
  [6, "Selling your own trading signals via Telegram", "Charge subscribers for your trade calls — legally sensitive if unlicensed.", "caution"],
  [7, "Selling forex \"Expert Advisor\" bots", "Build and sell automated forex trading bots.", "caution"],
  [8, "Selling custom trading indicators", "Build and sell custom charting indicators to traders.", "legit"],
  [9, "Arbitrage between crypto exchanges", "Exploit price differences between exchanges — thin margins, needs capital/speed.", "caution"],
  [10, "Crypto arbitrage bots (paid subscription tools)", "Sell access to arbitrage bot software.", "caution"],
  [11, "Matched betting (exploiting bookmaker free bets)", "Legal in some countries (notably UK) — exploits free bet offers for guaranteed small profit.", "caution"],
  [12, "Sports arbitrage betting", "Bet across bookmakers to lock in guaranteed profit from odds differences.", "caution"],
  [13, "Binary options trading", "Widely banned/illegal in many jurisdictions and heavily scam-associated.", "illegal"],
  [14, "Online poker/esports betting \"systems\"", "Sold as guaranteed win systems — mostly unreliable, gambling risk.", "risky"],
  [15, "Pump-and-dump signal groups", "Illegal market manipulation — avoid entirely.", "illegal"],
  [16, "Airdrop farming", "Use activity on new crypto protocols to qualify for token drops.", "caution"],
  [17, "Running multiple wallets to farm airdrops (Sybil farming)", "Against nearly every protocol's terms — accounts get blacklisted.", "illegal"],
  [18, "DeFi yield farming", "Provide liquidity to DeFi protocols for yield — real smart contract/rug-pull risk.", "risky"],
  [19, "Staking stablecoins for yield", "Earn interest by staking stablecoins on a platform.", "caution"],
  [20, "Lending crypto on platforms for interest", "Lend crypto assets for interest income — platform solvency risk.", "caution"],
  [21, "NFT flipping", "Buy and resell NFTs for profit — highly speculative, mostly declined market.", "risky"],
  [22, "Generative NFT art creation and sale", "Create and sell generative NFT art collections.", "caution"],
  [23, "Play-to-earn gaming", "Earn tokens by playing blockchain games — mostly collapsed post-Axie era, rarely profitable now.", "risky"],
  [24, "Metaverse virtual land flipping", "Buy/sell virtual land in metaverse platforms — speculative, low current demand.", "risky"],
  [25, "Creating and launching your own meme coin", "Legal grey zone, high scam-adjacent reputation, real legal risk if marketed deceptively.", "illegal"],
  [26, "Whitepaper writing for crypto projects", "Write technical/business whitepapers for crypto startups.", "legit"],
  [27, "Smart contract auditing", "Audit smart contracts for security flaws — needs real security expertise.", "legit"],
  [28, "Blockchain freelance development", "Build blockchain/Web3 applications for clients.", "legit"],
  [29, "Retail arbitrage (buy cheap, resell on Amazon/eBay)", "Needs starting capital to buy inventory — contradicts a no-capital constraint.", "caution"],
  [30, "Sneaker bot reselling", "Use bots to buy limited sneakers and resell at markup — needs capital and bot cost.", "caution"],
  [31, "Ticket scalping bots for concerts/events", "Automate ticket purchases to resell at markup — ethically and often legally dicey.", "risky"],
  [32, "Domain flipping", "Buy undervalued domains and resell for profit.", "legit"],
  [33, "Flipping social media/Instagram accounts", "Grow and sell social accounts — often against platform ToS.", "caution"],
  [34, "Flipping Discord servers", "Build and sell established Discord communities.", "caution"],
  [35, "Flipping small websites (Flippa-style)", "Buy/build and resell small websites for profit.", "legit"],
  [36, "\"Cash App flipping\" / \"Venmo flipping\"", "Advertised as doubling your money — these are scams, full stop.", "illegal"],
  [37, "Selling AI-generated \"low content\" books on Amazon KDP", "Sell AI-assisted journals, planners, coloring books on KDP.", "legit"],
  [38, "Selling full AI-written ebooks on KDP", "Publish AI-written ebooks for sale — saturated, quality bar rising.", "caution"],
  [39, "Selling AI art prints via print-on-demand", "Sell AI-generated art as printed products.", "legit"],
  [40, "Selling Midjourney/AI prompt packs", "Sell curated prompt packs on marketplaces like PromptBase.", "legit"],
  [41, "Selling custom GPT \"agents\" as productized SaaS", "Package a GPT-based tool as a subscription SaaS product.", "legit"],
  [42, "\"AI agency in a box\" — reselling automation templates", "Sell a business-in-a-box of automation templates and SOPs.", "legit"],
  [43, "AI voice cloning services", "Legally risky without explicit consent from the voice owner.", "illegal"],
  [44, "AI-generated music sold as royalty-free packs", "Sell AI-composed music packs for content creators.", "legit"],
  [45, "Reselling ChatGPT Plus/Claude subscriptions or \"AI access\"", "Usually violates the platform's terms of service.", "illegal"],
  [46, "Writing fake product reviews for pay", "Illegal in the US (FTC) and against every marketplace's ToS.", "illegal"],
  [47, "Fake app store review farms", "Against Apple/Google ToS — can get you banned/blacklisted.", "illegal"],
  [48, "Click farms / \"get paid to click ads\"", "Almost universally scams or ToS violations.", "illegal"],
  [49, "Bot-driven social media engagement selling", "Selling fake followers/likes — against platform ToS.", "illegal"],
  [50, "Survey panel \"systems\" claiming high payouts", "Legit surveys exist but pay very little; big-payout claims are oversold.", "caution"],
  [51, "Multi-level marketing product resale", "Legal, but 'get rich' framing is almost always false — income concentrated at the top.", "caution"],
  [52, "\"Passive income\" crypto MLMs", "Most are unregistered securities/Ponzi structures regularly shut down by regulators.", "illegal"],
  [53, "High-ticket coaching resale/franchise models via Instagram DMs", "Often a repackaged MLM in disguise.", "caution"],
  [54, "Amazon Mechanical Turk micro-tasks", "Complete small online tasks for small per-task pay.", "legit"],
  [55, "Remote online notary work", "US-specific, needs licensing.", "risky"],
  [56, "Medical billing/coding freelance", "Needs professional certification.", "risky"],
  [57, "Virtual bookkeeping certifications sold as fast-income paths", "The cert alone doesn't guarantee you clients.", "caution"],
  [58, "Freelance résumé/essay writing for students", "Academic ghostwriting for students is banned on major freelance platforms and violates academic integrity policies.", "illegal"],
  [59, "Contract \"chat moderator\" jobs for OnlyFans-style platforms", "Agency chatting on behalf of creators — see AI OFM section for detail.", "caution"],
  [60, "Discord community moderator paid gigs", "Get paid to moderate active Discord communities.", "legit"],
  [61, "Twitch/YouTube channel moderator paid gigs", "Get paid to moderate live chat for streamers/creators.", "legit"],
  [62, "Bug bounty hunting (HackerOne, Bugcrowd)", "Get paid for finding real security vulnerabilities — needs genuine skill.", "legit"],
  [63, "CTF (capture the flag) competition prize money", "Win cash prizes in cybersecurity competitions.", "legit"],
  [64, "Hackathon prize money", "Many hackathons are fully remote/async — submit code for prize money.", "legit"],
  [65, "Open source bounty platforms (Gitcoin, Algora)", "Get paid for completing bounty-tagged open source issues.", "legit"],
  [66, "GitHub Sponsors for open source work", "Get sponsored for maintaining valuable open source projects.", "legit"],
  [67, "Private blog network (PBN) link building", "Against Google's Webmaster Guidelines — sites get penalized.", "caution"],
  [68, "Guest post/backlink selling services", "Sell backlinks/guest posts — grey-hat SEO risk.", "caution"],
  [69, "\"White hat\" SEO reseller services", "Legit version of SEO services, slower but sustainable results.", "legit"],
  [70, "Faceless TikTok/Reels content farming for ad revenue share", "Post high-volume faceless short-form content for platform revenue share.", "legit"],
  [71, "Faceless YouTube automation channels", "YouTube has tightened 2025-26 policies on 'inauthentic' mass-produced content — demonetization risk.", "caution"],
  [72, "PLR (Private Label Rights) content reselling", "Legal but very low-value and saturated.", "caution"],
  [73, "Reselling online courses without a license", "Piracy — illegal.", "illegal"],
  [74, "\"Course flipping\" — buying cheap access and reselling seats", "Usually violates the course creator's terms.", "illegal"],
  [75, "Get-paid-to (GPT) sites for watching ads/videos", "Tiny payouts for watching ads/completing simple tasks.", "legit"],
  [76, "Cashback/reward apps", "Earn small cashback/rewards on purchases.", "legit"],
  [77, "Search engine evaluator programs", "Legit but low pay, slow ramp-up.", "legit"],
  [78, "Data labeling gig platforms (Remotasks, Scale AI)", "Label training data for AI models.", "legit"],
  [79, "User testing platforms", "Paid per test, small amounts per session.", "legit"],
  [80, "Sugar dating platforms", "Allowance-for-companionship arrangements — legal status varies, real safety/reputational risk.", "risky"],
  [81, "Paid \"girlfriend/boyfriend experience\" texting services", "Legal grey areas depending on jurisdiction and content.", "risky"],
  [82, "Camming/adult content platforms", "Legal in many places; real income potential, but requires ID verification — 'anonymous' isn't really possible.", "risky"],
  [83, "Amazon FBA private label", "Needs real capital ($2k-10k+) despite 'start for free' marketing.", "caution"],
  [84, "Dropshipping via TikTok Shop/Shopify", "Needs ad spend capital to actually generate sales.", "caution"],
  [85, "Real estate wholesaling", "Needs local licensing knowledge and network — not realistically remote/anonymous.", "risky"],
  [86, "Credit card churning for sign-up bonuses", "Needs good credit and access to US cards — not accessible from Sri Lanka.", "caution"],
  [87, "Credit repair services", "Regulated industry in the US; operating from abroad without registration is legally risky.", "risky"],
  [88, "Tax preparation services", "Needs jurisdiction-specific certification.", "risky"],
  [89, "Insurance lead generation/appointment setting", "Often requires licensing depending on what's promoted.", "risky"],
  [90, "Virtual real estate wholesaling via cold calling US homeowners", "Legally murky without proper disclosures and licensing.", "risky"],
  [91, "Flipping thrifted items on Depop/Poshmark", "Needs starting capital to buy inventory.", "caution"],
  [92, "Reselling wholesale liquidation pallets", "Needs significant starting capital.", "caution"],
  [93, "Buying and reselling web design \"seats\" (agency dropservicing)", "Legitimate version of the dropservicing model.", "legit"],
  [94, "Selling \"spreadsheet audit\" or \"SEO audit\" cold-call templates", "A thin service wrapped around a basic template.", "caution"],
  [95, "Selling \"how I made $10k online\" courses about an unproven method", "The actual business model behind many 'make money online' videos — the guru profits from teaching, not the method.", "caution"],
  [96, "Faceless \"AI news\" Twitter/X accounts monetized via revenue share", "Payouts have been wildly inconsistent and often overhyped.", "caution"],
  [97, "Reselling access to leaked/pirated software or tools", "Illegal.", "illegal"],
  [98, "Running a \"financial signal\" Discord charging subscription without a license", "Unlicensed paid financial advice is illegal in many countries.", "illegal"],
  [99, "Selling access to a private \"deal alert\" bot via subscription", "Legitimate if you build real value — saturated market.", "legit"],
  [100, "Instagram/TikTok \"growth agency\" guaranteeing bot-driven follower growth", "Same ToS violation as fake engagement, just repackaged as a service.", "illegal"],
];

const categoryFor = (n: number): string => {
  if (n <= 15) return "Trading & Markets";
  if (n <= 28) return "Crypto 'Free Money' Schemes";
  if (n <= 36) return "Flip Stuff You Don't Own Yet";
  if (n <= 45) return "AI Hype-Cycle Offers";
  if (n <= 50) return "Reviews, Engagement & Manipulation";
  if (n <= 53) return "MLM & Pyramid-Adjacent";
  if (n <= 61) return "Freelance/Gig Platforms (Oversold)";
  if (n <= 66) return "Bounty & Skill Competitions";
  if (n <= 69) return "SEO / Content Manipulation";
  if (n <= 74) return "Print-on-Demand & Content Mills";
  if (n <= 79) return "'Get Paid To' Apps & Tasks";
  if (n <= 82) return "Sugar / Companion Economy";
  if (n <= 90) return "High-Ticket (Hidden Prerequisites)";
  return "Misc 'Internet Famous' Hustles";
};

export const list2: Idea[] = raw.map(([num, title, desc, risk]) => ({
  id: `l2-${num}`,
  num,
  title,
  desc,
  risk: risk as Idea["risk"],
  category: categoryFor(num),
}));

export const list2Categories = Array.from(new Set(list2.map((i) => i.category)));
