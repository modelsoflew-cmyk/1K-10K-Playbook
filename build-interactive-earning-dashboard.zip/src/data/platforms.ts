import type { Risk } from "../types";

export interface Platform {
  name: string;
  desc: string;
  tag: Risk;
}

// Source: "micro task work I can start right now that pay good money around $100" thread
export const microtaskPlatforms: Platform[] = [
  {
    name: "Remotasks",
    desc: "Connected to Scale AI — data labeling, annotation, transcription, AI-chatbot evaluation work. Legit but inconsistent: some earn real money on stable/higher-skill projects, others report empty task queues and onboarding friction. Treat as a trickle that can grow, not a guarantee.",
    tag: "legit",
  },
  {
    name: "CrowdGen by Appen",
    desc: "Same category as Remotasks — AI training tasks, transcription, fact-checking. Sri Lanka-specific roles exist, e.g. Tamil transcription — language skills (English-Sinhala-Tamil) can unlock role-specific queues faster than generic ones.",
    tag: "legit",
  },
  {
    name: "UserTesting.com",
    desc: "Get paid per test (~$4-10 for 15-20 min) to try websites/apps and give screen + voice feedback. No face required on most tests.",
    tag: "legit",
  },
  {
    name: "Amazon Mechanical Turk",
    desc: "Micro-task marketplace — small tasks for small per-task pay. Fully text/browser based.",
    tag: "legit",
  },
  {
    name: "Lionbridge / Appen Search Evaluator Programs",
    desc: "Rate search engine/ad result quality to help train search algorithms. Legit but low pay and a slower ramp-up.",
    tag: "legit",
  },
];

export interface ContestSite {
  name: string;
  desc: string;
  category: string;
}

export const contestSites: ContestSite[] = [
  { name: "Freelancer.com Contests", desc: "Logo, web design, writing, naming contests — broadest variety, easiest entry, best volume play.", category: "General / Best Volume" },
  { name: "99designs Contests", desc: "Logo/brand identity contests, higher quality bar, bigger prizes ($200-1000+), but more competition.", category: "Design" },
  { name: "DesignCrowd", desc: "Similar to 99designs — logo/web/print design contests.", category: "Design" },
  { name: "DesignHill", desc: "Logo, business card, packaging design contests.", category: "Design" },
  { name: "Crowdspring", desc: "Brand identity, logo, product design, book cover contests.", category: "Design" },
  { name: "Squadhelp", desc: "Naming and tagline contests specifically — good if you're a wordsmith rather than a designer.", category: "Naming / Writing" },
  { name: "LogoMyWay", desc: "Logo-focused contests, smaller prizes but less competition.", category: "Design" },
  { name: "HatchWise", desc: "Logo, naming, and writing contests combined.", category: "Design / Writing" },
  { name: "Squadhelp Naming Contests", desc: "Business/product name contests, no design skill needed.", category: "Naming / Writing" },
  { name: "Reedsy Prompts", desc: "Short story contests, some with cash prizes — mostly reputation-building with occasional real payouts.", category: "Writing" },
  { name: "NYC Midnight", desc: "Writing contests with entry fees but real cash prizes — more competitive/skill-based.", category: "Writing" },
  { name: "Freelancer.com Video Contests", desc: "Same platform, separate video/animation contest category.", category: "Video / Animation" },
  { name: "Zooppa", desc: "Brand content and ad concept contests — less active than before, check current status.", category: "Video / Ad Concepts" },
  { name: "Tongal", desc: "Video/ad concept contests for brands with real budgets when active.", category: "Video / Ad Concepts" },
];
