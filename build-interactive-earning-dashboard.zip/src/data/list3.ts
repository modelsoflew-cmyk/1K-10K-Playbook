import type { Idea } from "../types";

// Source: "AI OFM" — AI OnlyFans Management + companion/creator economy adjacent (50 items)
const raw: [number, string, string, string][] = [
  [1, "Managing chats for a real creator using AI-assisted responses", "Increase message volume/tips for a real, consenting creator using AI-assisted drafting.", "caution"],
  [2, "\"Chatting agency\" — outsourced humans, AI-assisted for speed", "Run a team of chatters supported by AI tools.", "caution"],
  [3, "Selling AI-written chat scripts/sales funnels to OFM agencies", "Sell scripts/funnels as a product, not running chats yourself.", "legit"],
  [4, "Building a CRM/dashboard tool for OFM agencies", "Build software tools for agencies to track subscriber spend patterns.", "legit"],
  [5, "Selling \"PPV (pay-per-view) caption\" packs to creators/agencies", "Sell caption copywriting packs.", "legit"],
  [6, "Consulting for creators on pricing tier structure", "Advise on subscription/PPV/tip pricing structure.", "legit"],
  [7, "Selling a \"chatter training\" course/SOP to new agency owners", "Package your chatting process into a paid course/SOP.", "caution"],
  [8, "Building AI models to flag high-value (\"whale\") subscribers", "Build analytics tools identifying top-spending subscribers.", "legit"],
  [9, "Reselling OFM agency services white-label", "Run a white-label management company reselling agency services.", "caution"],
  [10, "Data/analytics dashboards for creators across platforms", "Build cross-platform earnings tracking tools.", "legit"],
  [11, "Building a fully AI-generated Instagram influencer persona", "Create a virtual (non-explicit) influencer for brand deals, no real person involved.", "legit"],
  [12, "Monetizing a virtual influencer via affiliate links and sponsorships", "Earn via affiliate/sponsorship deals on a virtual persona's account.", "legit"],
  [13, "Licensing a virtual persona's \"likeness\" to brands", "License your AI persona's image/brand to companies.", "legit"],
  [14, "Running an AI persona's TikTok for ad-revenue-share and brand deals", "Grow a virtual persona's TikTok for monetization.", "legit"],
  [15, "Selling \"behind the scenes\" AI persona content as a subscription", "Offer bonus persona content via paid subscription.", "legit"],
  [16, "Fully AI-generated adult-content personas monetized via subscription", "Legal status varies; many platforms restrict/ban synthetic performers — accounts and payouts get removed.", "risky"],
  [17, "\"AI girlfriend\" persona monetized via a fan platform (non-explicit)", "Legal in most places but ethically contested.", "caution"],
  [18, "Building your own AI companion chatbot app (subscription model)", "Build a subscription-based AI companion chatbot app.", "legit"],
  [19, "White-labeling an existing AI companion app framework", "Reskin an existing companion app framework as your own.", "legit"],
  [20, "Selling character \"personality packs\" for existing companion apps", "Sell custom character packs where platforms allow it.", "legit"],
  [21, "Building a niche AI companion app for a specific audience", "Target a specific underserved audience (language learners, fandoms, etc.).", "legit"],
  [22, "Consulting/dev work building companion chatbots for other founders", "Freelance dev work building companion bots for other people's startups.", "legit"],
  [23, "Voice-based AI companion apps (licensed, consented TTS only)", "Use only licensed/consented voices for any voice features.", "legit"],
  [24, "AI companion apps with GFE framing (non-explicit)", "A large, currently profitable category — but under real regulatory scrutiny in multiple jurisdictions.", "risky"],
  [25, "Memory-persistent AI companion apps", "More advanced, higher retention — technically harder to build well.", "legit"],
  [26, "Paid \"text a stranger\" companionship apps (chatting as yourself)", "Real human-to-human paid texting/companionship apps.", "caution"],
  [27, "Working as a chatter for existing companion/GFE apps", "Get hired to respond to users on someone else's app.", "caution"],
  [28, "AI-assisted (not fully automated) GFE texting services", "Legal grey area — risky if it implies talking to a specific real person when it's not.", "risky"],
  [29, "Building the backend infrastructure for GFE texting services", "Dev work only, sold as a service — not running the content side.", "legit"],
  [30, "Selling AI-generated content calendars/caption packs to OF creators", "Non-explicit copywriting/planning products sold to creators.", "legit"],
  [31, "Building analytics tools that predict optimal posting times", "Build scheduling/analytics tools for creators.", "legit"],
  [32, "AI-powered thumbnail/cover image generation service", "Offer AI-generated thumbnails/covers as a service.", "legit"],
  [33, "Selling AI voiceover services for creator promo content", "Provide licensed AI voiceovers for creator promotional content.", "legit"],
  [34, "Building a \"creator OS\" — scheduling/chat/analytics dashboard", "Build a comprehensive all-in-one creator management platform.", "legit"],
  [35, "Deepfake content services using real people's likenesses", "Illegal in a growing number of jurisdictions without consent, and against nearly every platform's ToS.", "illegal"],
  [36, "AI voice cloning of real creators/celebrities without consent", "Civil and often criminal liability (right of publicity, fraud).", "illegal"],
  [37, "\"Undressing\" or explicit-image-generation apps/services", "Illegal in many jurisdictions when applied to real, identifiable people.", "illegal"],
  [38, "Fake creator accounts using AI-generated faces to solicit subscriptions", "Fraud — soliciting money under false pretenses.", "illegal"],
  [39, "Scraping and reselling real creators' content as an \"AI-repackaged\" wrapper", "Copyright infringement.", "illegal"],
  [40, "Companion apps marketed toward minors or failing age-verification", "Serious legal exposure — a hard line, do not build regardless of framing.", "illegal"],
  [41, "AI-powered content repurposing tools (long-form to short-form)", "Sell tools/services turning long content into short clips, for creators generally.", "legit"],
  [42, "AI editing/color-grading services for creator content", "Offer AI-assisted video editing/color grading as a service.", "legit"],
  [43, "Building \"creator CRM\" tools tracking fan lifetime value", "Build tools tracking fan spending/engagement value.", "legit"],
  [44, "Selling AI-generated merch designs to creators for POD stores", "Design merch for creators' print-on-demand stores.", "legit"],
  [45, "AI-assisted contract/rate-card generation for brand deals", "Help creators generate contracts/rate cards for negotiations.", "legit"],
  [46, "Building creator \"media kits\" using AI design tools", "Design professional media kits for creators as a service.", "legit"],
  [47, "AI-powered comment moderation tools for creators", "Build tools that filter/moderate comments automatically.", "legit"],
  [48, "Selling AI-written email newsletter content to creators", "Write newsletter content helping creators build an owned audience.", "legit"],
  [49, "Fansly/Fanvue have more permissive AI-generated performer policies", "Fanvue markets itself as AI-friendly — most 'AI OFM' hype is actually about Fanvue, not OnlyFans.", "info"],
  [50, "Payment processors have tightened rules on AI adult content since 2024-25", "Makes accounts/payouts in this space unusually unstable right now.", "info"],
];

const categoryFor = (n: number): string => {
  if (n <= 10) return "AI OFM Core Model";
  if (n <= 17) return "Fully AI-Generated Virtual Personas";
  if (n <= 25) return "AI Companion / Chatbot Apps";
  if (n <= 29) return "Chat & Texting Services";
  if (n <= 34) return "Non-Explicit Creator Tools";
  if (n <= 40) return "⚠️ High-Risk / Do Not Build";
  if (n <= 48) return "Legitimate Creator-Economy Tools";
  return "Platform Realities (Info)";
};

export const list3: Idea[] = raw.map(([num, title, desc, risk]) => ({
  id: `l3-${num}`,
  num,
  title,
  desc,
  risk: risk as Idea["risk"],
  category: categoryFor(num),
}));

export const list3Categories = Array.from(new Set(list3.map((i) => i.category)));
